#ifndef LAMPORT_H
#define LAMPORT_H

#include "banking.h"

timestamp_t get_lamport_time();
timestamp_t inc_lamport_time();
timestamp_t set_lamport_time(timestamp_t new_time);

#endif //LAMPORT_H
