#include "banking.h"
#include "ipc.h"
#include "network.h"
#include "lamport.h"

void transfer(void * parent_data, local_id src, local_id dst, balance_t amount) {
        
        Message msg;
        msg.s_header.s_local_time  = inc_lamport_time();
        msg.s_header.s_magic       = MESSAGE_MAGIC;
        msg.s_header.s_type        = TRANSFER;
        msg.s_header.s_payload_len = sizeof(TransferOrder);

        TransferOrder *order = (TransferOrder *)&msg.s_payload;
        order->s_amount = amount;
        order->s_src = src;
        order->s_dst = dst;
        order->s_src = src;

        send(parent_data, src, &msg);
        printf("transfered \n");
        
        Message receivedMsg;
        receive(parent_data, dst, &receivedMsg);
        printf("received \n");
}

