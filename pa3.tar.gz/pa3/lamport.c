#include "banking.h"
#include "lamport.h"

timestamp_t lamport_time = 0;

timestamp_t get_lamport_time() {
        return lamport_time;
}

timestamp_t set_lamport_time(timestamp_t newTime) {
    timestamp_t returnedTime;
    if(lamport_time > newTime) {
        returnedTime = lamport_time+1;
    }
    else {
        returnedTime = newTime + 1;
    }
        return returnedTime;
}

timestamp_t inc_lamport_time() {
        return ++lamport_time;
}
