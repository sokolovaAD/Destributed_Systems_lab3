#include "common.h"
#include "ipc.h"
#include "pa2345.h"
#include "network.h"
#include "banking.h"
#include "opts.h"
#include "phases.h"

#include <getopt.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>



int main(int argc, char *argv[]) {
        struct params params;
        if (argc != 0) {
        getOptions(argc, argv, &params);
        }
        if(params.proc_num<1) return 1;
        if(params.proc_num>15) return 1;
        uint8_t n = params.proc_num;
        FILE *pipe_log = fopen(pipes_log, "w");
        FILE *event_log = fopen(events_log, "w");

        Process me;
        network(n, pipe_log, &me);
        fclose(pipe_log);

        if (me.id != PARENT_ID) {
                child_cycle(event_log, &me, params.balances[me.id - 1]);
        } else {
                parent_cycle(&me);
        }

        processClose(&me);

        return 0;
}
