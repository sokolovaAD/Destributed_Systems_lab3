#ifndef NETWORK_H
#define NETWORK_H

#include <unistd.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <stdlib.h>
#include <stdio.h>
#include "ipc.h"



typedef struct process {
        uint8_t id;
        uint8_t desc_num;
        int  readPipe[MAX_PROCESS_ID];
        int writePipe[MAX_PROCESS_ID];
} Process;


timestamp_t get_lamport_time();
timestamp_t inc_lamport_time();
timestamp_t set_lamport_time(timestamp_t new_time);

int waitAll(Process *process, int16_t type);
int makeNet(uint8_t x, Process *process, FILE *pipe_log, int *read, int *write);
int makePipes(uint8_t x, FILE *pipe_log, int *read, int *write);

void network(uint8_t x, FILE *pipe_log, Process *process);
void processClose(Process *process);


#endif //NETWORK_H
