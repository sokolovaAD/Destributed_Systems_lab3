#include "ipc.h"
#include "network.h"

#include <unistd.h>
#include <stdio.h>
#include <errno.h>

int send(void * self, local_id dst, const Message * mes) {
        Process *p = (Process *)self;
        if (write(p->writePipe[dst], (char *)mes, sizeof(MessageHeader) +
                                mes->s_header.s_payload_len) == -1) {
                perror("sending");
                return 1;
        }
        return 0;
}

int send_multicast(void * self, const Message * mes) {
        Process *p = (Process *)self;
        for (uint8_t i = 0; i < p->desc_num; ++i) {
                if (i == p->id)
                        continue;

                if (send(self, i, mes)) {
                        return 1;
                }
        }
        return 0;
}

int receive(void * self, local_id from, Message * mes) {
        Process *p = (Process *)self;
        while (read(p->readPipe[from], (char *)&(mes->s_header),
                                sizeof(MessageHeader)) == -1)
        {
                if (errno != EAGAIN) {
                        printf("receiving1\n");
                        return 1;
                }
        }
        uint16_t payload_len = mes->s_header.s_payload_len;
        set_lamport_time(mes->s_header.s_local_time);
        while (read(p->readPipe[from], (char *)mes->s_payload,
                                payload_len) != payload_len) {
                printf("receiving2\n");
                return 1;
        }
        return 0;
}

int receive_any(void * self, Message * mes) {
        Process *p = (Process *)self;
        int status;
        while (1) {
                for (size_t i = 0; i < p->desc_num; ++i) {
                        if (i == p->id) {
                                continue;
                        }

                        status = read(p->readPipe[i],
                                        (char *)&(mes->s_header),
                                                sizeof(MessageHeader));
                        if (status <= 0) {
                                continue;
                        }
                        uint16_t payload_len = mes->s_header.s_payload_len;
                        set_lamport_time(mes->s_header.s_local_time);
                        if (payload_len == 0) {
                                return 0;
                        }
                        read(p->readPipe[i], (char *)&(mes->s_payload),
                                        payload_len);
                        return 0;
                }
        }
        return 1;
}

