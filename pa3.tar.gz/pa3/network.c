#include "network.h"
#include "common.h"


timestamp_t lamport_time = 0;

timestamp_t inc_lamport_time() {
        return ++lamport_time;
}

timestamp_t get_lamport_time() {
        return lamport_time;
}

timestamp_t set_lamport_time(timestamp_t new_time) {
    //timestamp_t returnedTime=0;
    if(lamport_time>new_time) {
       lamport_time = lamport_time +1;
    }
    else{
        lamport_time = new_time+1;
    }
        return lamport_time;
}

int waitAll(Process *process, int16_t type) {
        for (uint8_t i = 1; i < process->desc_num; ++i) {
                if (i == process->id)
                        continue;
                Message msg;
                if (receive(process, i, &msg)) {
                        printf("Failed to receive: p = %d, i = %d\n",
                                        process->id, i);
                        return 1;
                }
              if (msg.s_header.s_type != type) {
                        printf("%s", "HHH:((( \n");
                }
                
                

        }
        return 0;
}

int makePipes(uint8_t n, FILE *pipe_log, int *read, int *write) {
    int desc[2];
    int k=100;
    for (int i=0; i<n;i++) {
        for (int j=0; j<n;j++) {
            if (i==j) continue;
            if(pipe(desc)==-1) {
                printf("error occured while opening the pipe");
                return 2;
            }
            fprintf(pipe_log, "Pipe from process %d to %d is ready\n",
            i, j);
            fcntl(desc[0], F_SETFL, O_NONBLOCK);
                        fcntl(desc[1], F_SETFL, O_NONBLOCK);
            read[i*k+j] = desc[0];
            write[j*k+i] = desc[1];
        }
    }
    
    return 0;
}


int makeNet(uint8_t n, Process *process, FILE *pipe_log, int *read, int *write) {
     int k=100;
    int numW=0, numR=0;
            for (int m=0; m<n;++m) {
                for (int l=0; l<n;++l) {
                    if(numW==process->id) numW++;
                    if(numR==process->id) numR++;
                    if (m==l) continue;
                    else if (((m*k+l)<(process->id*k+k))&&((m*k+l)>=(process->id*k))) {
                        if (process->id!=0) {
                            fprintf(pipe_log, "proc - %d; close read - %d\n", process->id ,read[m*k+l]);
                            process->writePipe[numW] = write[l*k+m];
                            numW++;
                            close(read[m*k+l]);
                            //fprintf(pipe_log, "proc - %d; close read - %d\n", process->id ,read[m*k+l]);
                        
                        }
                        else {
                            fprintf(pipe_log, "proc - %d; close read - %d\n", process->id  ,read[m*k+l]);
                            close(read[m*k+l]);
                            process->writePipe[numW] = write[l*k+m];
                            numW++;
                            //close(write[m*k+l]);
                            //fprintf(pipe_log, "proc - %d; close read - %d\n", process->id  ,read[m*k+l]);
                        }
                    }   
                    else if(((m*k+l)%k)==process->id) { 
                        process->readPipe[numR] = read[m*k+l];
                        numR++;
                        fprintf(pipe_log, "proc - %d; close write - %d\n", process->id ,write[l*k+m]);
                        close(write[l*k+m]);
                        //fprintf(pipe_log, "proc - %d; close write - %d\n", process->id ,write[m*k+l]);
                        
                    }
                    else {
                        fprintf(pipe_log, "proc - %d; close read/write - %d,%d\n", process->id  ,read[m*k+l], write[l*k+m]);
                        close(read[m*k+l]);
                        close(write[l*k+m]);
                        //fprintf(pipe_log, "proc - %d; close read/write - %d,%d\n", process->id  ,read[m*k+l], write[m*k+l]);

                    }
                }
            }

        
    process->readPipe[process->id] = 1000;
    process->writePipe[process->id] = 2000;

        
    



    return 0;
}




void network(uint8_t x, FILE *pipe_log, Process *process) {
    uint8_t n = x+1;
    int read_desc[n*110];
    int write_desc[n*110];
    makePipes(n, pipe_log, read_desc, write_desc);

 process->id=PARENT_ID;
    process->desc_num = n;
    for (int i=1; i<n; ++i) {
        pid_t pid = fork();
        if (pid==0) 
        {
            process->id = i;
            process->desc_num=n;
            break;
        }
    }
    
    makeNet(n, process, pipe_log, read_desc, write_desc);
    //for (int i=0; i<3;i++) {
      //  printf("process %d, opened[%d, %d]\n", process->id, process->readPipe[i], process->writePipe[i]);
    //}
    
    for(int i=0;i<n;i++) {
        printf("I am proc %d, i have reads %d, %d, %d;  writes %d, %d, %d == %d\n", process->id, process->readPipe[0],process->readPipe[1], process->readPipe[2], process->writePipe[0], process->writePipe[1], process->writePipe[2], process->desc_num);
    }
    
    
}

void processClose(Process *process){
    for (int i = 0; i < process->desc_num; ++i) {
                    //printf("proc: %d; read/write descs are closed - %d, %d\n",process->id, process->readPipe[i], process->writePipe[i]);
                        close(process->readPipe[i]);
                        close(process->writePipe[i]);
        }
}
