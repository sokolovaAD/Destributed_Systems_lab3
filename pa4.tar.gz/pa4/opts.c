#include "opts.h"

int getOptions(int argc, char** argv, struct params* opts, void *data) {
    int c;
    struct option long_opts[] = {
            {"mutexl", no_argument, (int*)data, 1},
            {0, 0, 0, 0}
    };


while( ( c = getopt_long(argc, argv, "p:", long_opts, NULL) ) != -1 ) {
        switch(c) {
            case 0: break;
            case 'p':
                opts->proc_num=strtol(optarg,NULL,10); break;
            
        }
    }

    return 0;
}
