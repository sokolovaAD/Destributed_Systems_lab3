#define _GNU_SOURCE
#include <stdio.h>
#include <getopt.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/wait.h>
#include <fcntl.h>
#include "common.h"
#include "ipc.h"
#include "pa2345.h"
#include "network.h"
#include "pa4.h"



timestamp_t proc_time = 0;
Queue *queue = NULL;
size_t done_cnt = 0;
uint8_t mutex_enabled;


timestamp_t getLamportTime(){
	return proc_time;
}

timestamp_t setLamportTime(timestamp_t new_time){
	proc_time = new_time > proc_time ? new_time : proc_time;
    return proc_time;
}

void incTime(){
	proc_time++;
}

void create_message(Message *msg, MessageType type, size_t length){
    memset(msg, 0, sizeof *msg);
    msg->s_header.s_magic = MESSAGE_MAGIC;
    msg->s_header.s_type = type;
    msg->s_header.s_local_time = getLamportTime();
    msg->s_header.s_payload_len = length;
}

void queue_push( Queue *queue, local_id pid, timestamp_t time ) {
    Queue *node;
    node = malloc( sizeof *node );
    node->pid   = pid;
    node->time  = time;
    node->next  = NULL;

    if( queue->front == NULL && queue->back == NULL ){
        queue->front = queue->back = node;
        return;
    }

    Queue *current = queue->front;
    Queue *prev = NULL;

    while( current != NULL ) {
        if( current->time > time
            || ( current->time == time && pid < current->pid ) ) {

            node->next = current;
            if( prev ) prev->next = node;

            if( current == queue->front ) queue->front = node;

            node = NULL;
            break;
        } else {
            prev = current;
            current = current->next;
        }
    }

    if( node ) {
        queue->back->next = node;
        queue->back = node;
        node = NULL;
    }
}

void QPop(Queue *queue ) {

    if( queue->front == NULL ) return;
    Queue *del = queue->front;
    if( queue->front == queue->back ) {
        queue->front = NULL;
        queue->back = NULL;
    }else {
        queue->front = queue->front->next;
    }
    free(del);
}


int request_cs(const void * self) {
    Data *handle = (Data*)self;
    Message msg;
    incTime();
    create_message(&msg, CS_REQUEST, 0);
    if( queue == NULL ){
        queue = malloc( sizeof *queue );
    }

    queue_push(queue, handle->src_pid, getLamportTime());
    int rc = send_multicast(handle, &msg);
    if( rc != 0 ) return rc;

    int replies_cnt = handle->proc_num - 2;
    while( replies_cnt > 0 || queue->front->pid != handle->src_pid ){
        rc = receive_any(handle, &msg);
        if( rc != 0 ) return rc;
        setLamportTime(msg.s_header.s_local_time);
        incTime();
        switch(msg.s_header.s_type){
            case CS_REQUEST:
                queue_push(queue, handle->last_msg_pid, msg.s_header.s_local_time);
                incTime();
                create_message(&msg, CS_REPLY, 0);
                int rc = send(handle, handle->last_msg_pid, &msg);
                if( rc != 0 ) return rc;
                break;
            case CS_RELEASE:
                QPop(queue);
                break;
            case CS_REPLY:
                replies_cnt--;
                break;
            case DONE:
                done_cnt++;
                break;
        }
    }

    return 0;
}


uint8_t childWork(Data *handle, void *data) {
	if( mutex_enabled )
		request_cs( handle);

	char buff[4096];

	int n = handle->src_pid * 5;
	for( int i = 1; i <= n; i++ ) {
		snprintf( buff, sizeof(buff), log_loop_operation_fmt, handle->src_pid, i, n );
		print( buff );
	}
	if( mutex_enabled )
		release_cs( handle );
	return 0;
}

int child_atexit(Data *handle, void *data){
	return 0;
}




int receive_all(Data *handle){
    Message msg;
    create_message(&msg, 0, 0);
    for(local_id i = 1; i < handle->proc_num - done_cnt; i++){
        int rc = receive(handle, i, &msg);
        if( rc != 0 ){
            (void)write(STDERR_FILENO, e_log_multicast_read, sizeof e_log_multicast);
            return 1;
        }
        setLamportTime(msg.s_header.s_local_time);
        incTime();
    }
    return 0;
}



int parent(Data *handle){
    int rc = 0;
    Message msg;
    create_message(&msg, 0, 0);
    rc = receive_all(handle);
    if( rc != 0 ) return 1;

    // Do work

    while(done_cnt < handle->proc_num - 1){
        rc = receive_any(handle, &msg);
        if( rc != 0 ) return 1;
        setLamportTime(msg.s_header.s_local_time);
        incTime();
        if( msg.s_header.s_type == DONE ) done_cnt++;
    }

    if( rc != 0 ) return 1;

    for(local_id pid = 1; pid < handle->proc_num; pid++){
        wait(NULL);
    }
    return 0;
}

int child(Data *handle, void *data, FILE *log) {
    int rc = 0;
    incTime();

    Message msg;
    create_message(&msg, STARTED, 0);
    char entry[100];
    snprintf(entry, 100, log_started_fmt, getLamportTime(),
             handle->src_pid, getpid(), PARENT_ID, 0);
    fprintf(log, "%s", entry);
    


    rc = send_multicast(handle, &msg);
    if( rc != 0 ){
        (void)write(STDERR_FILENO, e_log_multicast, sizeof e_log_multicast);
        return 1;
    }

    rc = receive_all(handle);
    if( rc != 0 ) return 1;
    snprintf(entry, 100, log_received_all_started_fmt,
             getLamportTime(), handle->src_pid);
    fprintf(log, "%s", entry);
    


    // Do work
    childWork(handle, data);


    snprintf(entry, 100, log_done_fmt,
             getLamportTime(), handle->src_pid, 0);
    fprintf(log, "%s", entry);
    
    incTime();
    msg.s_header.s_local_time = getLamportTime();

    msg.s_header.s_payload_len = strlen(msg.s_payload);
    msg.s_header.s_type = DONE;



    rc = send_multicast(handle, &msg);
    if( rc < 0 ){
        (void)write(STDERR_FILENO, e_log_multicast, sizeof e_log_multicast);
        return 1;
    }

    while(done_cnt < handle->proc_num - 2){
        rc = receive_any(handle, &msg);
        if( rc != 0 ) return 1;
        setLamportTime(msg.s_header.s_local_time);
        incTime();
        if( msg.s_header.s_type == DONE ) done_cnt++;
    }

    snprintf(entry, 100, log_received_all_done_fmt,
             getLamportTime(), handle->src_pid);
    fprintf(log, "%s", entry);


    return child_atexit(handle, data);
}




int release_cs(const void * self) {
    Data *handle = (Data*)self;

    QPop(queue);
    Message msg;
    incTime();
    create_message(&msg, CS_RELEASE, 0);

    int rc = send_multicast(handle, &msg);
    if( rc != 0 ) return rc;

    return 0;
}



