#ifndef PA4_H

#define _GNU_SOURCE
#include <stdio.h>
#include <getopt.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/wait.h>
#include <fcntl.h>
#include "common.h"
#include "ipc.h"
#include "pa2345.h"
#include "opts.h"
#include "network.h"

uint8_t mutex_enabled;
static int events_log_fd = -1;

typedef struct Queue {
    struct Queue *front, *back, *next;
    local_id pid;
    timestamp_t time;
} Queue;




static const char e_log_write[] = "Error: failed to write event read log\n";
static const char e_log_multicast[] = "Error: failed to send multicast\n";
static const char e_log_multicast_read[] = "Error: failed to read multicast\n";


timestamp_t getLamportTime();
timestamp_t setLamportTime(timestamp_t new_time);
void incTime();
void create_message(Message *msg, MessageType type, size_t length);
void queue_push( Queue *queue, local_id pid, timestamp_t time );
void QPop(Queue *queue ) ;
int request_cs(const void * self) ;
uint8_t childWork(Data *handle, void *data);
int parent(Data *handle);
int child(Data *handle, void *data, FILE *log);
int release_cs(const void * self);
int receive_all(Data *handle);


#endif //PA4_H
