#define _GNU_SOURCE
#include <stdio.h>
#include <getopt.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/wait.h>
#include <fcntl.h>
#include "common.h"

#include "ipc.h"
#include "pa4.h"
#include "network.h"

#include <unistd.h>
#include <stdio.h>
#include <errno.h>

int send(void * self, local_id dst, const Message * msg) {

    Data *h = (Data*)self;
    if( dst == h->src_pid ) return 0;



    size_t msg_size = sizeof msg->s_header + msg->s_header.s_payload_len;
    int rc = write(h->writePipe[dst], msg, msg_size);
    if( rc < 0 || rc != msg_size ) return -1;

    return 0;
}

int send_multicast(void * self, const Message * msg) {

    Data *h = (Data*)self;

    for(local_id pid = 0; pid < h->proc_num; pid++){
        int rc = send(self, pid, msg);
        if( rc < 0 ) return -1;
    }
    return 0;
}

int receive(void * self, local_id from, Message * msg) {

    Data *h = (Data*)self;
    if( from == h->src_pid ) return 0;

    while( 1 ){
        int rc = read(h->readPipe[from], msg, sizeof msg->s_header);
        if( rc <= 0 ) {
            goto sleep;
        }
        rc = read(h->readPipe[from], msg->s_payload, msg->s_header.s_payload_len);
        if( rc >= 0 ) {
            return 0;
        }
        sleep:
        usleep(1000);
    }
}

int receive_any(void * self, Message * msg) {

    Data *h = (Data*)self;
    while( 1 ){
        for(local_id pid = 0; pid < h->proc_num; pid++){
            if( pid == h->src_pid ) continue;


            int rc = read(h->readPipe[pid], msg, sizeof msg->s_header);
            if( rc <= 0 ) {
                continue;
            }
            rc = read(h->readPipe[pid], msg->s_payload, msg->s_header.s_payload_len);
            if( rc >= 0 ) {
                h->last_msg_pid = pid;
                //printf("lastpid: %d", pid);
                return 0;
            }
        }
        usleep(1000);
    }
    return 0;
}
