#include "common.h"
#include "ipc.h"
#include "pa2345.h"

#include "opts.h"


#include <getopt.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <getopt.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>
#include <fcntl.h>
#include "common.h"
#include "ipc.h"
#include "pa2345.h"
#include "opts.h"
#include "pa4.h"



int main(int argc, char *argv[]) {
        int rc = 0;
        

	uint8_t mutex_enabled_ = 0;
        struct params params;
        getOptions(argc, argv, &params, &mutex_enabled_);
	int proc_num = params.proc_num+1;
	if( proc_num < 0 ) return 1;

	Data handle;
        PipeFD *channel_table = malloc(proc_num * proc_num * sizeof *channel_table);
        if( channel_table == NULL ) return 1;

        memset(&handle, 0, sizeof handle);
        handle.proc_num = proc_num;
        handle.channel_table = channel_table;
        handle.parent_pid = getpid();
	mutex_enabled = mutex_enabled_;
    

	rc = create_pipes(&handle);
	if( rc != 0 ) return rc;

	int is_parent = spawn_childs(&handle);
	if( is_parent < 0 ) return 2;

	if( is_parent ){
		rc = parent(&handle);
	}else{
		rc = child(&handle, NULL);
	}

	free(handle.channel_table);
	return rc;




        /*struct params params;
        if (argc != 0) {
        getOptions(argc, argv, &params);
        }
        if(params.proc_num<1) return 1;
        if(params.proc_num>15) return 1;
        uint8_t n = params.proc_num;
        FILE *pipe_log = fopen(pipes_log, "w");
        FILE *event_log = fopen(events_log, "w");

        Process me;
        network(n, pipe_log, &me);
        fclose(pipe_log);

        if (me.id != PARENT_ID) {
                child_cycle(event_log, &me, params.balances[me.id - 1]);
        } else {
                parent_cycle(&me);
        }

        processClose(&me);

        return 0;*/
}
