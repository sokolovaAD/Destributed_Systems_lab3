#include "common.h"
#include "ipc.h"
#include "pa2345.h"
#include "network.h"

#include "opts.h"


#include <getopt.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <getopt.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>
#include <fcntl.h>
#include "common.h"
#include "ipc.h"
#include "pa2345.h"
#include "opts.h"
#include "pa4.h"



int main(int argc, char *argv[]) {
        int rc = 0;
        

	uint8_t mutex_enabled_ = 0;
        struct params params;
        getOptions(argc, argv, &params, &mutex_enabled_);
	int proc_num = params.proc_num+1;
	if( proc_num < 0 ) return 1;
        if(proc_num>15) return 0;
        mutex_enabled = mutex_enabled_;
	
        FILE *pipe_log = fopen(pipes_log, "w");
        FILE *event_log = fopen(events_log, "w");
        Data me;
        network(proc_num, pipe_log, &me);
        fclose(pipe_log);

        if (me.src_pid != PARENT_ID) {
                rc = child(&me, NULL, event_log);
        } else {
                rc = parent(&me);
        }

        processClose(&me);

        return 0;
        
        
        
        
}
