#ifndef NETWORK_H
#define NETWORK_H

#include <unistd.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <stdlib.h>
#include <stdio.h>
#include "ipc.h"




typedef struct {
    local_id src_pid;
    int  readPipe[MAX_PROCESS_ID];
    int writePipe[MAX_PROCESS_ID];
    size_t proc_num;
    pid_t parent_pid;
    local_id last_msg_pid;
} Data;


int waitAll(Data *process, int16_t type);
int makeNet(uint8_t x, Data *process, FILE *pipe_log, int *read, int *write);
int makePipes(uint8_t x, FILE *pipe_log, int *read, int *write);

void network(uint8_t x, FILE *pipe_log, Data *process);
void processClose(Data *process);


#endif //NETWORK_H
